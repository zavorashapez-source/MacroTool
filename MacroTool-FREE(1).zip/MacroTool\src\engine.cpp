#include "engine.h"
#include "monitor.h"
#include <algorithm>
#include <random>
#include <unordered_set>

// Small per-thread RNG for Frame Better humanization.
static int RandInt(int lo, int hi) {
    if (hi <= lo) return lo;
    thread_local std::mt19937 rng((unsigned)(QpcNow() ^ (uintptr_t)GetCurrentThreadId()));
    return lo + (int)(rng() % (unsigned)(hi - lo + 1));
}

namespace {

struct TimerHolder {
    HANDLE h = nullptr;
    ~TimerHolder() {
        if (h) CloseHandle(h);
    }
};
thread_local TimerHolder tlTimer;

HANDLE ThreadTimer() {
    if (!tlTimer.h) {
        tlTimer.h = CreateWaitableTimerExW(nullptr, nullptr, CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS);
        if (!tlTimer.h) tlTimer.h = CreateWaitableTimerExW(nullptr, nullptr, 0, TIMER_ALL_ACCESS);
    }
    return tlTimer.h;
}

// High-resolution sleep (sub-millisecond on Windows 10 1803+). Returns true when `cancel`
// fired first, so stopping a repeating macro takes effect immediately.
bool Wait(int ms, HANDLE cancel) {
    if (ms <= 0) return cancel && WaitForSingleObject(cancel, 0) == WAIT_OBJECT_0;
    HANDLE t = ThreadTimer();
    LARGE_INTEGER due;
    due.QuadPart = -(LONGLONG)ms * 10000;
    if (!t || !SetWaitableTimer(t, &due, 0, nullptr, nullptr, FALSE)) {
        if (cancel) return WaitForSingleObject(cancel, ms) == WAIT_OBJECT_0;
        Sleep(ms);
        return false;
    }
    if (cancel) {
        HANDLE hs[2] = {cancel, t};
        if (WaitForMultipleObjects(2, hs, FALSE, INFINITE) == WAIT_OBJECT_0) {
            CancelWaitableTimer(t);
            return true;
        }
        return false;
    }
    WaitForSingleObject(t, INFINITE);
    return false;
}

Engine* g_engine = nullptr;

LRESULT CALLBACK KbProc(int n, WPARAM w, LPARAM l) {
    if (n == HC_ACTION && g_engine) {
        auto* k = (KBDLLHOOKSTRUCT*)l;
        if (!(k->flags & LLKHF_INJECTED)) {
            bool down = w == WM_KEYDOWN || w == WM_SYSKEYDOWN;
            if (g_engine->Handle((int)k->vkCode, down)) return 1;
        }
    }
    return CallNextHookEx(nullptr, n, w, l);
}

LRESULT CALLBACK MsProc(int n, WPARAM w, LPARAM l) {
    if (n == HC_ACTION && w != WM_MOUSEMOVE && g_engine) {
        auto* m = (MSLLHOOKSTRUCT*)l;
        if (!(m->flags & LLMHF_INJECTED)) {
            if (w == WM_MOUSEWHEEL) {
                int key = (short)HIWORD(m->mouseData) > 0 ? kWheelUp : kWheelDown;
                bool block = g_engine->Handle(key, true);
                g_engine->Handle(key, false);
                if (block) return 1;
            } else {
                int key = 0;
                bool down = false;
                switch (w) {
                    case WM_LBUTTONDOWN: key = VK_LBUTTON; down = true; break;
                    case WM_LBUTTONUP: key = VK_LBUTTON; break;
                    case WM_RBUTTONDOWN: key = VK_RBUTTON; down = true; break;
                    case WM_RBUTTONUP: key = VK_RBUTTON; break;
                    case WM_MBUTTONDOWN: key = VK_MBUTTON; down = true; break;
                    case WM_MBUTTONUP: key = VK_MBUTTON; break;
                    case WM_XBUTTONDOWN:
                    case WM_XBUTTONUP:
                        key = HIWORD(m->mouseData) == XBUTTON1 ? VK_XBUTTON1 : VK_XBUTTON2;
                        down = w == WM_XBUTTONDOWN;
                        break;
                }
                if (key && g_engine->Handle(key, down)) return 1;
            }
        }
    }
    return CallNextHookEx(nullptr, n, w, l);
}

}  // namespace

// ---------------------------------------------------------------- tester feed

namespace Tester {
static std::mutex mu;
static std::vector<TesterEvent> queue;
static std::atomic<bool> listening{false};
static HWND wnd = nullptr;
static UINT wmsg = 0;

void SetNotify(HWND w, UINT m) {
    wnd = w;
    wmsg = m;
}
void SetListening(bool on) {
    listening = on;
    if (!on) {
        std::lock_guard lk(mu);
        queue.clear();
    }
}
static void Push(TesterEvent e) {
    if (!listening) return;
    std::lock_guard lk(mu);
    bool was = queue.empty();
    if (queue.size() < 5000) queue.push_back(std::move(e));
    if (was && wnd) PostMessageW(wnd, wmsg, 0, 0);
}
std::vector<TesterEvent> Drain() {
    std::lock_guard lk(mu);
    return std::exchange(queue, {});
}
}  // namespace Tester

// ---------------------------------------------------------------- input

namespace Input {
std::atomic<bool> dryRun{false};
static std::mutex mu;
static std::unordered_set<int> held;

static bool Extended(int k) {
    switch (k) {
        case VK_RCONTROL: case VK_RMENU: case VK_INSERT: case VK_DELETE: case VK_HOME: case VK_END:
        case VK_PRIOR: case VK_NEXT: case VK_LEFT: case VK_RIGHT: case VK_UP: case VK_DOWN:
        case VK_NUMLOCK: case VK_DIVIDE: case VK_LWIN: case VK_RWIN: case VK_APPS:
            return true;
    }
    return false;
}

static void Raw(int k, bool down) {
    INPUT in{};
    if (k == kWheelUp || k == kWheelDown) {
        if (!down) return;
        in.type = INPUT_MOUSE;
        in.mi.dwFlags = MOUSEEVENTF_WHEEL;
        in.mi.mouseData = (DWORD)(k == kWheelUp ? WHEEL_DELTA : -WHEEL_DELTA);
        SendInput(1, &in, sizeof(INPUT));
        return;
    }
    DWORD dn = 0, up = 0, data = 0;
    switch (k) {
        case VK_LBUTTON: dn = MOUSEEVENTF_LEFTDOWN; up = MOUSEEVENTF_LEFTUP; break;
        case VK_RBUTTON: dn = MOUSEEVENTF_RIGHTDOWN; up = MOUSEEVENTF_RIGHTUP; break;
        case VK_MBUTTON: dn = MOUSEEVENTF_MIDDLEDOWN; up = MOUSEEVENTF_MIDDLEUP; break;
        case VK_XBUTTON1: dn = MOUSEEVENTF_XDOWN; up = MOUSEEVENTF_XUP; data = XBUTTON1; break;
        case VK_XBUTTON2: dn = MOUSEEVENTF_XDOWN; up = MOUSEEVENTF_XUP; data = XBUTTON2; break;
    }
    if (dn) {
        in.type = INPUT_MOUSE;
        in.mi.dwFlags = down ? dn : up;
        in.mi.mouseData = data;
    } else {
        in.type = INPUT_KEYBOARD;
        WORD scan = (WORD)MapVirtualKeyW((UINT)k, MAPVK_VK_TO_VSC);
        in.ki.wVk = (WORD)k;
        in.ki.wScan = scan;
        // Games read scan codes; keys without one (media keys) fall back to the virtual key.
        in.ki.dwFlags = (scan ? KEYEVENTF_SCANCODE : 0) | (down ? 0 : KEYEVENTF_KEYUP) |
                        (Extended(k) ? KEYEVENTF_EXTENDEDKEY : 0);
    }
    {
        std::lock_guard lk(mu);
        if (down) held.insert(k);
        else held.erase(k);
    }
    SendInput(1, &in, sizeof(INPUT));
}

void Send(int k, bool down) {
    Tester::Push({false, L"", k, down, QpcNow()});
    if (dryRun) return;
    Raw(k, down);
}

void Move(int dx, int dy) {
    TesterEvent te{false, L"", kMouseMove, false, QpcNow()};
    te.dx = dx;
    te.dy = dy;
    Tester::Push(te);
    if (dryRun || (!dx && !dy)) return;
    int biggest = std::max(std::abs(dx), std::abs(dy));
    // Split big turns into small deltas; some games clamp a single huge delta.
    int chunks = std::max(1, (biggest + 199) / 200);
    std::vector<INPUT> ins;
    for (int i = 0; i < chunks; i++) {
        INPUT in{};
        in.type = INPUT_MOUSE;
        in.mi.dwFlags = MOUSEEVENTF_MOVE;
        in.mi.dx = (int)((long long)dx * (i + 1) / chunks - (long long)dx * i / chunks);
        in.mi.dy = (int)((long long)dy * (i + 1) / chunks - (long long)dy * i / chunks);
        ins.push_back(in);
    }
    if (!ins.empty()) SendInput((UINT)ins.size(), ins.data(), sizeof(INPUT));
}

void ReleaseStuck() {
    std::vector<int> keys;
    {
        std::lock_guard lk(mu);
        keys.assign(held.begin(), held.end());
    }
    for (int k : keys) Raw(k, false);
}
}  // namespace Input

// ---------------------------------------------------------------- engine

void Engine::Start(HWND notify, UINT msg) {
    notify_ = notify;
    notifyMsg_ = msg;
    g_engine = this;
    hookThread_ = std::thread([this] { HookThread(); });
}

void Engine::HookThread() {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
    MSG m;
    PeekMessageW(&m, nullptr, WM_USER, WM_USER, PM_NOREMOVE);
    HHOOK hk = SetWindowsHookExW(WH_KEYBOARD_LL, KbProc, GetModuleHandleW(nullptr), 0);
    HHOOK hm = SetWindowsHookExW(WH_MOUSE_LL, MsProc, GetModuleHandleW(nullptr), 0);
    while (GetMessageW(&m, nullptr, 0, 0) > 0) {
        TranslateMessage(&m);
        DispatchMessageW(&m);
    }
    if (hk) UnhookWindowsHookEx(hk);
    if (hm) UnhookWindowsHookEx(hm);
}

void Engine::Shutdown() {
    {
        std::unique_lock lk(mu_);
        capture_ = false;
        recording_ = false;
        ReleaseAllLocked();
        idle_.wait_for(lk, std::chrono::milliseconds(1500), [&] { return active_.empty(); });
    }
    Input::ReleaseStuck();
    if (hookThread_.joinable()) {
        DWORD tid = GetThreadId(hookThread_.native_handle());
        for (int i = 0; i < 200 && !PostThreadMessageW(tid, WM_QUIT, 0, 0); i++) Sleep(5);
        hookThread_.join();
    }
    g_engine = nullptr;
}

static std::wstring Sig(const std::vector<Step>& steps) {
    std::wstring s;
    for (auto& st : steps) s += Fmt(L"%d%c%d,%d,%d;", st.key, st.kind, st.ms, st.dx, st.dy);
    return s;
}

void Engine::Reindex(const Config& cfg) {
    int tk;
    toggleVk_ = KeyParse(cfg.toggleKey, tk) ? tk : VK_F8;
    sound_ = cfg.toggleSound;
    onlyInGame_ = cfg.onlyInGame;
    timing_ = 0;  // only frame timing remains
    humanize_ = cfg.timing == L"FrameHuman";

    std::map<int, std::vector<std::shared_ptr<const Compiled>>> idx;
    std::unordered_map<int, std::shared_ptr<const Compiled>> byId;
    for (auto& m : cfg.macros) {
        int k;
        if (!m.enabled || !KeyParse(m.trigger, k)) continue;
        try {
            auto c = std::make_shared<Compiled>();
            c->id = m.id;
            c->name = m.name;
            c->trigger = k;
            c->press = ParseSteps(m.steps, cfg.binds);
            c->release = ParseSteps(m.releaseSteps, cfg.binds);
            c->holdMs = m.holdMs;
            c->stepDelay = m.stepDelay;
            c->repeatDelay = std::max(1, m.repeatDelay);
            c->repeat = m.repeat;
            c->toggle = m.toggle;
            c->block = m.blockTrigger;
            c->sig = Fmt(L"%d|%d|%d|%d|%d%d%d|", k, c->holdMs, c->stepDelay, c->repeatDelay, c->repeat, c->toggle,
                         c->block) + Sig(c->press) + L"|" + Sig(c->release);
            idx[k].push_back(c);
            byId[m.id] = c;
        } catch (const FormatError&) {
            // The UI flags the macro; the engine just skips it.
        }
    }
    std::lock_guard lk(mu_);
    index_ = std::move(idx);
    // A macro that was edited, disabled or deleted while running must still let go of its keys.
    std::vector<int> stale;
    for (auto& [id, r] : running_) {
        auto f = byId.find(id);
        if (f == byId.end() || f->second->sig != r->c->sig) stale.push_back(id);
    }
    for (int id : stale) ReleaseLocked(id);
}

void Engine::SetEnabled(bool on) {
    std::lock_guard lk(mu_);
    enabled_ = on;
    if (!on) ReleaseAllLocked();
}

void Engine::BeginCapture(int token) {
    std::lock_guard lk(mu_);
    captureToken_ = token;
    capture_ = true;
}

void Engine::CancelCapture() { capture_ = false; }

void Engine::BeginRecord() {
    std::lock_guard lk(mu_);
    rec_.clear();
    recStart_ = QpcNow();
    recording_ = true;
}

std::vector<InputEvent> Engine::EndRecord() {
    std::lock_guard lk(mu_);
    recording_ = false;
    return std::exchange(rec_, {});
}

size_t Engine::RecordCount() {
    std::lock_guard lk(mu_);
    return rec_.size();
}

std::vector<EngineMsg> Engine::Drain() {
    std::lock_guard lk(mu_);
    return std::exchange(msgs_, {});
}

bool Engine::IsRunning(int macroId) {
    std::lock_guard lk(mu_);
    return running_.count(macroId) > 0;
}

void Engine::Post(EngineMsg m) {
    bool was = msgs_.empty();
    msgs_.push_back(m);
    if (was && notify_) PostMessageW(notify_, notifyMsg_, 0, 0);
}

bool Engine::ForegroundIsGame() {
    HWND fg = GetForegroundWindow();
    if (fg == lastFg_) return lastFgGame_;
    lastFg_ = fg;
    lastFgGame_ = false;
    DWORD pid = 0;
    GetWindowThreadProcessId(fg, &pid);
    if (pid) {
        HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        if (h) {
            wchar_t path[MAX_PATH * 2];
            DWORD len = (DWORD)std::size(path);
            if (QueryFullProcessImageNameW(h, 0, path, &len)) {
                std::wstring_view p(path, len);
                size_t slash = p.find_last_of(L"\\/");
                std::wstring_view name = slash == std::wstring_view::npos ? p : p.substr(slash + 1);
                lastFgGame_ = IEquals(name, L"FortniteClient-Win64-Shipping.exe");
            }
            CloseHandle(h);
        }
    }
    return lastFgGame_;
}

void Engine::SetLocked(bool locked) {
    std::lock_guard lk(mu_);
    locked_ = locked;
    if (locked) {
        capture_ = false;
        recording_ = false;
        ReleaseAllLocked();
    }
}

bool Engine::Handle(int k, bool down) {
    if (locked_) return false;
    std::lock_guard lk(mu_);
    if (capture_) {
        if (down && k != VK_LBUTTON) {
            capture_ = false;
            Post({k == VK_ESCAPE ? EngineMsg::CaptureCanceled : EngineMsg::Captured, 0, k, captureToken_});
        }
        return k != VK_LBUTTON;
    }
    if (recording_) {
        long long now = (long long)QpcToMs(QpcNow() - recStart_);
        if (k == VK_ESCAPE) {
            // Esc finishes the recording from inside the game; the game never sees it.
            if (down) {
                recording_ = false;
                Post({EngineMsg::RecordStopped});
            }
            return true;
        }
        rec_.push_back({k, down, now});
        return false;
    }
    bool repeatPress = false;
    auto it = std::find(held_.begin(), held_.end(), k);
    if (down) {
        if (it != held_.end()) repeatPress = true;
        else held_.push_back(k);
    } else {
        if (it != held_.end()) held_.erase(it);
        std::vector<int> rel;
        for (auto& [id, r] : running_)
            if (r->c->trigger == k && !r->c->toggle) rel.push_back(id);
        for (int id : rel) ReleaseLocked(id);
    }
    if (k == toggleVk_) {
        if (down && !repeatPress) {
            bool on = !enabled_;
            enabled_ = on;
            if (!on) ReleaseAllLocked();
            if (sound_) std::thread([on] { Beep(on ? 880 : 440, 90); }).detach();
            Post({EngineMsg::Toggled});
        }
        return true;
    }
    if (!enabled_) return false;
    if (typing_ && GetForegroundWindow() == mainWnd_.load()) return false;
    // Only fire while Fortnite is the active window, so nothing triggers on the desktop.
    if (onlyInGame_ && !ForegroundIsGame()) return false;
    auto f = index_.find(k);
    if (f == index_.end()) return false;
    bool block = false;
    for (auto& c : f->second) {
        block |= c->block;
        if (down && !repeatPress) {
            if (c->toggle && running_.count(c->id)) ReleaseLocked(c->id);
            else StartLocked(c);
        }
    }
    return block;
}

void Engine::StartLocked(const std::shared_ptr<const Compiled>& c) {
    if (active_.count(c->id)) return;
    auto r = std::make_shared<Run>();
    r->c = c;
    r->cancel = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    running_[c->id] = r;
    active_[c->id] = r;
    Post({EngineMsg::Fired, c->id});
    Tester::Push({true, c->name, 0, false, QpcNow()});
    std::thread([this, r] { Worker(r); }).detach();
}

void Engine::ReleaseLocked(int id) {
    auto it = running_.find(id);
    if (it == running_.end()) return;
    SetEvent(it->second->cancel);
    running_.erase(it);
    Post({EngineMsg::Stopped, id});
}

void Engine::ReleaseAllLocked() {
    std::vector<int> ids;
    for (auto& [id, r] : running_) ids.push_back(id);
    for (int id : ids) ReleaseLocked(id);
}

void Engine::Worker(std::shared_ptr<Run> r) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
    const Compiled& c = *r->c;
    for (;;) {
        RunSteps(c.press, c);
        int rd = humanize_.load() ? RandInt(c.repeatDelay * 85 / 100, c.repeatDelay * 118 / 100) : c.repeatDelay;
        if (!c.repeat || Wait(rd, r->cancel)) break;
    }
    WaitForSingleObject(r->cancel, INFINITE);
    RunSteps(c.release, c);
    std::lock_guard lk(mu_);
    auto it = active_.find(c.id);
    if (it != active_.end() && it->second == r) active_.erase(it);
    idle_.notify_all();
}

void Engine::RunSteps(const std::vector<Step>& steps, const Compiled& c) {
    (void)c;
    bool human = humanize_.load();
    int frame = Monitor::frameMs.load();
    for (size_t i = 0; i < steps.size(); i++) {
        const Step& s = steps[i];
        switch (s.kind) {
            // Frame Better nudges user waits a touch so they aren't identical every run.
            case L'w': Wait(human ? s.ms + RandInt(0, s.ms / 10 + 2) : s.ms, nullptr); continue;
            case L'd': Input::Send(s.key, true); break;
            case L'u': Input::Send(s.key, false); break;
            case L'm': Input::Move(s.dx, s.dy); break;
            default:
                // Legacy: instant tap. Better: hold a varied 3-10 ms so it always registers and looks human.
                Input::Send(s.key, true);
                int hold = human ? RandInt(3, 10) : 0;
                if (hold > 0) Wait(hold, nullptr);
                Input::Send(s.key, false);
                break;
        }
        if (i + 1 < steps.size()) {
            int delay = frame + (human ? RandInt(0, 6) : 0);
            if (delay > 0) Wait(delay, nullptr);
        }
    }
}
