#pragma once
#include "util.h"
#include <cstdint>
#include <string>

// Compile-time XOR so the KeyAuth wiring (URL, app name, owner ID, public key)
// doesn't show up in a plain `strings` dump of the exe. This is not encryption:
// anyone who runs the program under a debugger still sees the decoded value. It
// only keeps the strings from being read at a glance. Each OBF() site uses its
// own key; the plaintext literal is consumed at compile time (consteval) so it
// is never emitted, and decoding reads a `volatile` key so the optimiser can't
// fold the result back to plaintext.
namespace obf {

constexpr uint8_t Next(uint8_t k) { return (uint8_t)(k * 7u + 0x5Du); }

template <size_t N>
struct Str {
    char d[N];
    uint8_t seed;
};

template <size_t N>
consteval Str<N> Make(const char (&s)[N], uint8_t k) {
    Str<N> r{};
    r.seed = k;
    uint8_t key = k;
    for (size_t i = 0; i < N; i++) {
        r.d[i] = (char)((uint8_t)s[i] ^ key);
        key = Next(key);
    }
    return r;
}

template <size_t N>
inline std::string Decode(const Str<N>& s) {
    std::string out(N ? N - 1 : 0, '\0');
    volatile uint8_t key = s.seed;
    for (size_t i = 0; i + 1 < N; i++) {
        out[i] = (char)((uint8_t)s.d[i] ^ (uint8_t)key);
        key = Next((uint8_t)key);
    }
    return out;
}

}  // namespace obf

// Decoded narrow / wide string. The literal must be a plain "..." so sizeof works.
#define OBF_A(s) (obf::Decode(obf::Make<sizeof(s)>((s), (uint8_t)(((__LINE__) * 131u + 41u) & 0xFF))))
#define OBF_W(s) (Widen(OBF_A(s)))
