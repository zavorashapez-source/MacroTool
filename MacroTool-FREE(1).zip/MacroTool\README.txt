﻿Macro Tool - FREE & open source
================================
Fortnite macro tool (edits, builds, resets fired from a key). Free, no license key.

RUN:   bin\MacroTool.exe   (asks for admin - needed so key presses reach the game)
       F8 turns all macros on/off in game.

BUILD (if you want to edit it):
  1) Visual Studio 2022 (Community is free) + "Desktop development with C++".
  2) Double-click build.bat. It finds VS itself.
  3) Output: bin\MacroTool.exe and bin\MacroTool-dev.exe (dev = no admin prompt, for testing).
  Self-test: bin\MacroTool-dev.exe --selftest out.txt

NOTE: no aim/trigger bot included - this is only key/click macros.
