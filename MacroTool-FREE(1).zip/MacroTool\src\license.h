#pragma once
#include "util.h"
#include <cstdint>

// Set to 1 for the free, no-key public release: the app runs without activation
// and KeyAuth is never contacted. 0 = the licensed build that needs a key.
#ifndef FREE_BUILD
#define FREE_BUILD 0
#endif

// The KeyAuth app name, owner ID, version and URL are kept XOR-obfuscated in
// license.cpp (see AppName/Owner/Version/ApiUrl) so they aren't readable in the
// exe. Edit them there if the app changes.

bool Ed25519Verify(const uint8_t sig[64], const uint8_t* msg, size_t n, const uint8_t pk[32]);

struct LicenseResult {
    bool ok = false;
    std::wstring error;
    std::wstring plan;     // subscription name, e.g. "default"
    long long expiry = 0;  // unix seconds
};

namespace License {
bool Configured();
// Talks to KeyAuth (blocking, call off the UI thread): init, then license login bound to this PC.
LicenseResult Activate(const std::wstring& key);
std::wstring Hwid();
// The key is kept encrypted for this Windows user (DPAPI) so it doesn't need typing each launch.
std::wstring LoadKey();
void SaveKey(const std::wstring& key);
void ForgetKey();
// Checks a signed KeyAuth response: Ed25519 over timestamp + body with KeyAuth's public key.
bool VerifySigned(const std::string& timestamp, const std::string& body, const std::string& sigHex, long long nowSec,
                  std::wstring* why);
}  // namespace License
